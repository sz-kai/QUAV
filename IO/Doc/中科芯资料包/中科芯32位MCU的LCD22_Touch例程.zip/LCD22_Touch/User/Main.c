#include "cs32f10x.h"
#include "LTM022A69B.h"
#include "User_systick.h"
#include "usart.h"
#include "Touch.h"


unsigned char read_res ;

 typedef struct 
{
	unsigned int  x;//LCD��coordinates

	unsigned int  y;
	unsigned long x_ad_val; //ADC value
	unsigned long y_ad_val;						   	    
	unsigned char  pen_status;//The pen of the state
			  
}_touch_dot;

void display_touch_debug();
void lcd_test(void);
extern _touch_dot touch_dot;


int main(void)
{
    lcd_test();
    while(1);
}

void lcd_test(void)
{
		uint16_t i;
 	SystemInit();
	//USART_Configuration();
	
	lcd_init();
	lcd_init();
//	lcd_display_test();
	TOUCH_init();
	
	lcd_display_string( "CPU:CS32F103C8T6       ", BLACK, GREEN, 0, 1 );
  lcd_display_string( "www.cksic.com          ", BLACK, GREEN, 0, 3 );
	while(1)
	{
		read_res=Read_Continue();
 		lcd_draw_bigdot(BLACK,(touch_dot.x-20),(touch_dot.y-2));

	}  	
}
void display_touch_debug()
{        //ADC results show
        lcd_display_string("READ SUCCESS:",BLACK,GREEN,1,3);
        lcd_display_number(14,3,read_res,6);

        lcd_display_string("X AD Val:",BLACK,GREEN,1,4);
        lcd_display_number(10,4,touch_dot.x_ad_val,6);

        lcd_display_string("Y AD Val:",BLACK,GREEN,1,5);
        lcd_display_number(10,5,touch_dot.y_ad_val,6);

        //Display coordinates
        lcd_display_string("X:",BLACK,GREEN,1,6);
        lcd_display_number(10,6,touch_dot.x,5);
        lcd_display_string("Y:",BLACK,GREEN,1,7);
        lcd_display_number(10,7,touch_dot.y,5);

}

