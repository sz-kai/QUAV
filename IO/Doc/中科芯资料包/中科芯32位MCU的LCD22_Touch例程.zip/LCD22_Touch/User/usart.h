/*********************************************************************************************************
*
* File                : usart.h
* Hardware Environment: 
* Build Environment   : RealView MDK-ARM  Version: 4.20
* Version             : V1.0
* By                  : 
*
*                                  (c) Copyright 2005-2011, CKS
*                                       http://www.cksic.com
*                                          All Rights Reserved
*
*********************************************************************************************************/

#ifndef _USART_H
#define _USART_H

#include <stdio.h>
#include <cs32f10x.h>

void Rcc_Configuration(void);
void UsartGPIO_Configuration(void);
void USART_Configuration(void);
void UsartGPIO_CTRT_Configuration(void);
void USART_CTRT_Configuartion(void);

#endif /*_USART_H*/
